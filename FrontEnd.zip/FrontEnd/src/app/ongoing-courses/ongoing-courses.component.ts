import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ongoing-courses',
  templateUrl: './ongoing-courses.component.html',
  styleUrls: ['./ongoing-courses.component.css']
})
export class OngoingCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
